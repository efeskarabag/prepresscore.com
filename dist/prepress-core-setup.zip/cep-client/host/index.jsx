// Prepress Core - Host (ExtendScript) Engine
// Illustrator üzerinde çalışacak ana yönlendirici (Router)

function runScriptFile(filePath) {
    try {
        var scriptFile = new File(filePath);
        if (!scriptFile.exists) {
            return "ERROR: Dosya bulunamadı: " + filePath;
        }

        // Scripti çalıştır
        $.evalFile(scriptFile);
        
        return "SUCCESS";
    } catch (e) {
        return "ERROR: " + e.message;
    }
}

function getIllustratorScripts() {
    try {
        var presetsFolder = new Folder(app.path + "/Presets.localized");
        if (!presetsFolder.exists) {
            presetsFolder = new Folder(app.path + "/Presets");
        }
        if (!presetsFolder.exists) {
            presetsFolder = new Folder(Folder.startup + "/Presets");
        }
        if (!presetsFolder.exists) {
            presetsFolder = new Folder(app.path);
        }

        var scriptsFolders = [];
        if (presetsFolder.exists) {
            var presetsContents = presetsFolder.getFiles();
            for (var i = 0; i < presetsContents.length; i++) {
                if (presetsContents[i] instanceof Folder) {
                    // Hem English (Scripts) hem Türkçe (Scriptler) klasörlerini kontrol et
                    var scriptsSubFolder = new Folder(presetsContents[i].fullName + "/Scripts");
                    if (scriptsSubFolder.exists) {
                        scriptsFolders.push(scriptsSubFolder);
                    }
                    var scriptlerSubFolder = new Folder(presetsContents[i].fullName + "/Scriptler");
                    if (scriptlerSubFolder.exists) {
                        scriptsFolders.push(scriptlerSubFolder);
                    }
                }
            }
            
            var directScriptsFolder = new Folder(presetsFolder.fullName + "/Scripts");
            if (directScriptsFolder.exists) {
                scriptsFolders.push(directScriptsFolder);
            }
            var directScriptlerFolder = new Folder(presetsFolder.fullName + "/Scriptler");
            if (directScriptlerFolder.exists) {
                scriptsFolders.push(directScriptlerFolder);
            }
        }

        var scriptsList = [];
        for (var j = 0; j < scriptsFolders.length; j++) {
            scanFolderForScripts(scriptsFolders[j], scriptsList);
        }

        // ExtendScript'te JSON kütüphanesi varsayılan olarak bulunmadığı için manuel JSON oluşturuyoruz.
        var jsonParts = [];
        for (var k = 0; k < scriptsList.length; k++) {
            var item = scriptsList[k];
            var decodedName = decodeURI(item.name);
            var decodedPath = decodeURI(item.path);
            var escapedName = decodedName.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
            var escapedPath = decodedPath.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
            jsonParts.push('{"name":"' + escapedName + '","path":"' + escapedPath + '","type":"LOCAL"}');
        }
        
        return '[' + jsonParts.join(',') + ']';
    } catch (e) {
        return "ERROR: " + e.message;
    }
}

function scanFolderForScripts(folder, list) {
    if (!folder.exists) return;
    var files = folder.getFiles();
    for (var i = 0; i < files.length; i++) {
        var file = files[i];
        if (file instanceof Folder) {
            if (file.name.indexOf(".") !== 0) {
                scanFolderForScripts(file, list);
            }
        } else if (file instanceof File) {
            var ext = file.name.substring(file.name.lastIndexOf(".")).toLowerCase();
            if (ext === ".jsx" || ext === ".js") {
                list.push({
                    name: file.name,
                    path: file.fullName
                });
            }
        }
    }
}
