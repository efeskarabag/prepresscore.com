#!/bin/bash
# Prepress Core Mac Installer
clear
echo "==================================================="
echo "  Prepress Core Hub - macOS Kurulum Aracı"
echo "==================================================="
echo ""

# Scriptin çalıştığı klasörü bul
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
TARGET_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/prepress-core"

echo "1. Eski eklenti dosyaları temizleniyor..."
if [ -d "$TARGET_DIR" ]; then
    rm -rf "$TARGET_DIR"
fi

echo "2. Yeni dosyalar kopyalanıyor..."
mkdir -p "$TARGET_DIR"
cp -R "$SCRIPT_DIR/../cep-client/" "$TARGET_DIR/"

if [ $? -ne 0 ]; then
    echo "[HATA] Dosyalar kopyalanamadı! Lütfen scriptin yanındaki klasör yapısını bozmadığınızdan emin olun."
    read -p "Çıkmak için Enter'a basın..."
    exit 1
fi

echo "3. Adobe eklenti izinleri (PlayerDebugMode) ayarlanıyor..."
for i in {8..15}
do
    defaults write com.adobe.CSXS.$i PlayerDebugMode 1 2>/dev/null
done

echo ""
echo "==================================================="
echo "  [BAŞARILI] Prepress Core Hub kuruldu!"
echo "  Lütfen Adobe Illustrator programını yeniden başlatın."
echo "==================================================="
echo ""
