@echo off
chcp 65001 >nul
echo ===================================================
echo   Prepress Core Hub - Windows Kurulum Aracı
echo ===================================================
echo.

:: Yönetici yetkisi kontrolü
net session >nul 2>&1
if %errorLevel% == 0 (
    set TARGET_DIR="C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\prepress-core"
    echo [BİLGİ] Kurulum tüm kullanıcılar için yapılıyor (Yönetici Modu)...
) else (
    set TARGET_DIR="%APPDATA%\Adobe\CEP\extensions\prepress-core"
    echo [BİLGİ] Kurulum sadece mevcut kullanıcı için yapılıyor...
)

echo.
echo 1. Eski eklenti dosyaları temizleniyor...
if exist %TARGET_DIR% (
    rmdir /S /Q %TARGET_DIR%
)

echo 2. Yeni dosyalar kopyalanıyor...
mkdir %TARGET_DIR% 2>nul
xcopy /E /Y /I "%~dp0..\cep-client" %TARGET_DIR% >nul

if %errorLevel% NEQ 0 (
    echo [HATA] Dosyalar kopyalanamadı! Lütfen ZIP dosyasını klasöre çıkartıp kurulumu tekrar çalıştırın.
    pause
    exit /b
)

echo 3. Adobe eklenti izinleri (PlayerDebugMode) ayarlanıyor...
:: Adobe CC 2018'den CC 2026'ya kadar (CSXS 8 ila 15) tüm versiyonlar için debug modunu aktif et
for /L %%i in (8,1,15) do (
    reg add "HKEY_CURRENT_USER\Software\Adobe\CSXS.%%i" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo.
echo ===================================================
echo   [BAŞARILI] Prepress Core Hub kuruldu!
echo   Lütfen Adobe Illustrator programını yeniden başlatın.
echo ===================================================
echo.
pause
