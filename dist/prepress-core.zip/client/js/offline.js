const fs = require('fs');
const path = require('path');
const os = require('os');

// Platforma göre cache dizini
const appDataPath = os.platform() === 'win32' 
    ? (process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'))
    : path.join(os.homedir(), 'Library', 'Application Support');

const CACHE_DIR = path.join(appDataPath, 'PrepressCore');
const MANIFEST_FILE = path.join(CACHE_DIR, 'scripts_manifest.json');
const OFFLINE_LIMIT_MS = 24 * 60 * 60 * 1000; // 24 saat

function initCacheDir() {
    if (!fs.existsSync(CACHE_DIR)) {
        fs.mkdirSync(CACHE_DIR, { recursive: true });
    }
}

function saveScriptsToCache(scripts) {
    initCacheDir();
    const manifest = {
        last_successful_sync: Date.now(),
        scripts: scripts
    };
    fs.writeFileSync(MANIFEST_FILE, JSON.stringify(manifest, null, 2));
}

function cacheScriptBuffer(scriptId, encryptedBuffer) {
    initCacheDir();
    const scriptPath = path.join(CACHE_DIR, `${scriptId}.aes`);
    fs.writeFileSync(scriptPath, encryptedBuffer);
}

function getScriptBufferFromCache(scriptId) {
    const scriptPath = path.join(CACHE_DIR, `${scriptId}.aes`);
    if (fs.existsSync(scriptPath)) {
        return fs.readFileSync(scriptPath);
    }
    return null;
}

function loadScriptsFromCache() {
    if (!fs.existsSync(MANIFEST_FILE)) {
        return { error: 'Yerel önbellek bulunamadı. Lütfen internete bağlanın.' };
    }

    try {
        const data = fs.readFileSync(MANIFEST_FILE, 'utf-8');
        const manifest = JSON.parse(data);

        const timeDiff = Date.now() - manifest.last_successful_sync;
        if (timeDiff > OFFLINE_LIMIT_MS) {
            return { error: 'Çevrimdışı çalışma süresi (24 saat) doldu. Lütfen ağa bağlanın.' };
        }

        return { scripts: manifest.scripts, isOffline: true };
    } catch (e) {
        return { error: 'Yerel önbellek bozuk.' };
    }
}

module.exports = {
    saveScriptsToCache,
    cacheScriptBuffer,
    getScriptBufferFromCache,
    loadScriptsFromCache
};
