// Global JS Hata Yakalayıcılar (Debug Kolaylığı)
window.onerror = function(message, source, lineno, colno, error) {
    if (typeof showToast === 'function') {
        showToast("Hata: " + message + " (" + lineno + ". satır)", "error", 10000);
    } else {
        alert("Hata: " + message + " (" + lineno + ". satır)");
    }
    return false;
};
window.onunhandledrejection = function(event) {
    const reason = event.reason && event.reason.message ? event.reason.message : event.reason;
    if (typeof showToast === 'function') {
        showToast("Hata: " + reason, "error", 10000);
    } else {
        alert("Hata: " + reason);
    }
};

const csInterface = new CSInterface();
let machineId = "UNKNOWN";

// Node.js Modülleri (Manifest'te nodejs aktif olmalı)
let fs, path, machineIdSync, child_process, os, cryptoUtils, offlineUtils, silentInstallUtils;

try {
    if (typeof require !== 'undefined') {
        fs = require('fs');
        path = require('path');
        os = require('os');
        machineIdSync = require('node-machine-id').machineIdSync;
        child_process = require('child_process');
        cryptoUtils = require(path.join(__dirname, 'client', 'js', 'crypto.js'));
        offlineUtils = require(path.join(__dirname, 'client', 'js', 'offline.js'));
        silentInstallUtils = require(path.join(__dirname, 'client', 'js', 'silentInstall.js'));
        
        machineId = machineIdSync(true);
    } else {
        showToast("Node.js (require) aktif değil! manifest.xml kontrol edilmeli.", "error");
    }
} catch (e) {
    document.addEventListener('DOMContentLoaded', () => {
        showToast("Node.js Yükleme Hatası: " + e.message, "error", 8000);
    });
}

// SortableJS'i yerel olarak require et (CEP Node.js ortamı için en güvenli ve kararlı yöntem)
let Sortable = typeof window !== 'undefined' ? window.Sortable : null;
if (typeof require !== 'undefined' && typeof path !== 'undefined') {
    try {
        // Resmi Adobe CEP API'si ile uzantı klasörünün kesin yolunu alıyoruz
        const extPath = decodeURI(window.__adobe_cep__.getSystemPath("extension"));
        const sortablePath = path.join(extPath, 'client', 'js', 'Sortable.min.js');
        const sMod = require(sortablePath);
        Sortable = sMod && sMod.default ? sMod.default : sMod;
    } catch(err) {
        console.error("SortableJS absolute path require failed, trying relative and fallback:", err);
        try {
            // Alternatif: Parent klasördeki node_modules'tan dene
            const parentSortablePath = path.join(__dirname, '..', 'node_modules', 'sortablejs', 'Sortable.min.js');
            const sMod = require(parentSortablePath);
            Sortable = sMod && sMod.default ? sMod.default : sMod;
        } catch(e) {
            console.error("SortableJS fallback require failed, trying global window:", e);
        }
    }
}
if (!Sortable && typeof window !== 'undefined') {
    Sortable = window.Sortable;
}
console.log("SortableJS Library Status:", typeof Sortable !== 'undefined' ? "Loaded successfully" : "Failed to load");


let SERVER_URL = 'https://api.prepresscore.com/api';
let isServerUrlLocked = false;

try {
    if (typeof require !== 'undefined' && fs && path) {
        const extPath = decodeURI(window.__adobe_cep__.getSystemPath("extension"));
        const configPath = path.join(extPath, 'config.json');
        if (fs.existsSync(configPath)) {
            const configContent = fs.readFileSync(configPath, 'utf8');
            const config = JSON.parse(configContent);
            if (config && config.serverUrl) {
                let val = config.serverUrl.trim();
                if (val.endsWith('/')) {
                    val = val.slice(0, -1);
                }
                if (!val.endsWith('/api') && !val.includes('/api/')) {
                    val = val + '/api';
                }
                SERVER_URL = val;
                if (config.lockServerUrl) {
                    isServerUrlLocked = true;
                }
            }
        }
    }
} catch (e) {
    console.error("config.json okuma hatası:", e);
}

if (!isServerUrlLocked) {
    SERVER_URL = localStorage.getItem('setting_server_url') || SERVER_URL;
}

let authToken = localStorage.getItem('prepress_token');

// Global Modül Verileri
let serverScripts = [];
let localScripts = [];
let currentSortableInstance = null;
let isEditMode = false;
let hiddenScriptIds = JSON.parse(localStorage.getItem('prepress_hidden_ids') || '[]');
let customGroups = JSON.parse(localStorage.getItem('prepress_custom_groups') || '[]');
let renamedScripts = JSON.parse(localStorage.getItem('prepress_renamed_scripts') || '{}');

// Yeni DOM Elementleri
const btnEditMode = document.getElementById('btn-edit-mode');
const editModeBanner = document.getElementById('edit-mode-banner');
const btnEditAddGroup = document.getElementById('btn-edit-add-group');
const btnEditReset = document.getElementById('btn-edit-reset');
const btnEditDone = document.getElementById('btn-edit-done');

// Ayarlar ve Filtre Durumları (localStorage üzerinden okunur)
let settings = {
    runScripts: localStorage.getItem('setting_run_scripts') !== 'false', // varsayılan true
    runInstalled: localStorage.getItem('setting_run_installed') === 'true',
    showLocal: localStorage.getItem('setting_show_local') === 'true'
};

let currentFilters = {
    search: '',
    layout: localStorage.getItem('filter_layout') || 'FLAT'
};

// Polling için değişkenler
let knownScriptIds = JSON.parse(localStorage.getItem('prepress_known_ids') || '[]');
let pollingInterval = null;
const POLL_INTERVAL_MS = 20000; // 20 saniye

// DOM Elementleri
const authSection = document.getElementById('auth-section');
const moduleGrid = document.getElementById('module-grid');
const groupedContainer = document.getElementById('grouped-container');
const filterControls = document.getElementById('filter-controls');
const inputLicense = document.getElementById('input-license');
const btnLogin = document.getElementById('btn-login');
const loginError = document.getElementById('login-error');
const btnSync = document.getElementById('btn-sync');
const btnLogout = document.getElementById('btn-logout');
const btnSettings = document.getElementById('btn-settings');
const offlineBanner = document.getElementById('offline-banner');
const toastContainer = document.getElementById('toast-container');

// Uygulama Görüntüleyici Iframe Elementleri
const appViewer = document.getElementById('app-viewer');
const appIframe = document.getElementById('app-iframe');
const btnCloseApp = document.getElementById('btn-close-app');

// Ayarlar Modalı Elementleri
const settingsModal = document.getElementById('settings-modal');
const btnCloseSettings = document.getElementById('btn-close-settings');
const settingRunScripts = document.getElementById('setting-run-scripts');
const settingRunInstalled = document.getElementById('setting-run-installed');
const settingShowLocal = document.getElementById('setting-show-local');
const settingServerUrl = document.getElementById('setting-server-url');

// Filtre Kontrol Elemanları
const searchInput = document.getElementById('search-input');
const btnLayoutToggle = document.getElementById('btn-layout-toggle');
const iconLayoutFlat = document.getElementById('icon-layout-flat');
const iconLayoutGrouped = document.getElementById('icon-layout-grouped');

// =============================================
// TOAST BİLDİRİM SİSTEMİ
// =============================================
function showToast(message, type = 'info', duration = 4000) {
    const icons = {
        success: '✓',
        error: '✕',
        warning: '!',
        info: 'i'
    };

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.style.setProperty('--toast-duration', duration + 'ms');
    toast.innerHTML = `
        <div class="toast-icon">${icons[type] || icons.info}</div>
        <div class="toast-body">${message}</div>
        <div class="toast-progress"></div>
    `;

    toastContainer.appendChild(toast);

    const autoRemove = setTimeout(() => {
        dismissToast(toast);
    }, duration);

    toast.addEventListener('click', () => {
        clearTimeout(autoRemove);
        dismissToast(toast);
    });
}

function dismissToast(toast) {
    toast.classList.add('toast-exit');
    toast.addEventListener('animationend', () => {
        toast.remove();
    });
}

// =============================================
// BİLDİRİM BADGE (Kırmızı Nokta)
// =============================================
function showSyncBadge() {
    if (btnSync.querySelector('.notification-badge')) return;
    const badge = document.createElement('span');
    badge.className = 'notification-badge';
    btnSync.appendChild(badge);
}

function hideSyncBadge() {
    const badge = btnSync.querySelector('.notification-badge');
    if (badge) badge.remove();
}

// =============================================
// AYARLAR VE FİLTRELEME BAĞLANTILARI
// =============================================
function initFiltersAndSettings() {
    // Ayarlar modal aç/kapa
    if (btnSettings) {
        btnSettings.addEventListener('click', () => {
            settingsModal.classList.remove('hidden');
        });
    }
    if (btnCloseSettings) {
        btnCloseSettings.addEventListener('click', () => {
            settingsModal.classList.add('hidden');
        });
    }
    window.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
            settingsModal.classList.add('hidden');
        }
    });

    // Checkbox durumları ve kayıt mantığı
    if (settingRunScripts) {
        settingRunScripts.checked = settings.runScripts;
        settingRunScripts.addEventListener('change', (e) => {
            settings.runScripts = e.target.checked;
            localStorage.setItem('setting_run_scripts', settings.runScripts);
            showToast(settings.runScripts ? "Modülleri panelden çalıştırma aktif." : "Modülleri panelden çalıştırma pasif.", "info");
        });
    }
    if (settingRunInstalled) {
        settingRunInstalled.checked = settings.runInstalled;
        settingRunInstalled.addEventListener('change', (e) => {
            settings.runInstalled = e.target.checked;
            localStorage.setItem('setting_run_installed', settings.runInstalled);
            showToast(settings.runInstalled ? "ZXP eklentilerini panelden açma aktif." : "ZXP eklentilerini panelden açma pasif.", "info");
        });
    }
    if (settingShowLocal) {
        settingShowLocal.checked = settings.showLocal;
        settingShowLocal.addEventListener('change', async (e) => {
            settings.showLocal = e.target.checked;
            localStorage.setItem('setting_show_local', settings.showLocal);
            if (settings.showLocal) {
                await fetchLocalScripts();
            } else {
                localScripts = [];
                applyFiltersAndRender();
            }
            showToast(settings.showLocal ? "Yerel scriptleri gösterme aktif." : "Yerel scriptleri gösterme pasif.", "info");
        });
    }

    if (settingServerUrl) {
        if (isServerUrlLocked) {
            // Eğer sunucu adresi kilitliyse arayüzde gizle
            const serverUrlSettingItem = settingServerUrl.closest('.setting-item');
            if (serverUrlSettingItem) {
                serverUrlSettingItem.style.display = 'none';
            }
        } else {
            settingServerUrl.value = SERVER_URL;
            settingServerUrl.addEventListener('change', (e) => {
                let val = e.target.value.trim();
                if (!val) {
                    val = 'http://localhost:3000/api';
                }
                if (val.endsWith('/')) {
                    val = val.slice(0, -1);
                }
                if (!val.endsWith('/api') && !val.includes('/api/')) {
                    val = val + '/api';
                }
                SERVER_URL = val;
                settingServerUrl.value = SERVER_URL;
                localStorage.setItem('setting_server_url', SERVER_URL);
                showToast("Merkez sunucu adresi güncellendi: " + SERVER_URL, "success");
            });
        }
    }

    // Arama Girişi
    if (searchInput) {
        searchInput.value = currentFilters.search;
        searchInput.addEventListener('input', (e) => {
            currentFilters.search = e.target.value;
            applyFiltersAndRender();
        });
    }

    // Görünüm Değiştirme Butonu
    if (btnLayoutToggle) {
        updateLayoutToggleIcon();
        btnLayoutToggle.addEventListener('click', () => {
            currentFilters.layout = (currentFilters.layout === 'FLAT') ? 'GROUPED' : 'FLAT';
            localStorage.setItem('filter_layout', currentFilters.layout);
            if (isEditMode && currentFilters.layout === 'FLAT') {
                toggleEditMode(); // Flat layout'a geçerken düzenleme modunu kapat
            }
            updateLayoutToggleIcon();
            applyFiltersAndRender();
        });
    }
}

function updateLayoutToggleIcon() {
    if (currentFilters.layout === 'FLAT') {
        iconLayoutFlat.classList.remove('hidden');
        iconLayoutGrouped.classList.add('hidden');
        if (btnEditMode) {
            btnEditMode.classList.add('layout-flat-disabled');
            btnEditMode.setAttribute('title', 'Kişiselleştirmek için önce Kategori Görünümüne geçin');
        }
    } else {
        iconLayoutFlat.classList.add('hidden');
        iconLayoutGrouped.classList.remove('hidden');
        if (btnEditMode) {
            btnEditMode.classList.remove('layout-flat-disabled');
            btnEditMode.setAttribute('title', 'Kişiselleştir (Grupla / Sırala / Gizle)');
        }
    }
}

// =============================================
// YEREL SCRIPTLERI SCANN ETME (ExtendScript)
// =============================================
function fetchLocalScripts() {
    return new Promise((resolve) => {
        if (!settings.showLocal) {
            localScripts = [];
            resolve();
            return;
        }

        csInterface.evalScript('getIllustratorScripts()', (result) => {
            if (result.startsWith("ERROR:")) {
                console.error("Local Scripts Load Error:", result);
                showToast("Yerel scriptler yüklenirken hata oluştu: " + result, "error");
                localScripts = [];
            } else {
                try {
                    const parsed = JSON.parse(result);
                    localScripts = parsed.map(item => {
                        const decodedName = decodeURIComponent(item.name);
                        const decodedPath = decodeURIComponent(item.path);
                        return {
                            id: 'local:' + decodedPath,
                            name: decodedName,
                            path: decodedPath,
                            type: 'LOCAL',
                            description: 'Illustrator Yerel Menü Scripti'
                        };
                    });
                } catch (e) {
                    console.error("Local script parsing error:", e, result);
                    localScripts = [];
                }
            }
            applyFiltersAndRender();
            resolve();
        });
    });
}

// =============================================
// ANA UYGULAMA MANTIĞI
// =============================================
document.addEventListener('DOMContentLoaded', () => {
    initThemeColor();
    initFiltersAndSettings();
    initEditModeControls();

    if (authToken) {
        if (filterControls) filterControls.classList.remove('hidden');
        if (btnSettings) btnSettings.classList.remove('hidden');
        if (btnEditMode) btnEditMode.classList.remove('hidden');
        fetchScripts();
    }

    btnLogin.addEventListener('click', handleLogin);
    btnSync.addEventListener('click', () => {
        hideSyncBadge();
        fetchScripts();
    });
    btnLogout.addEventListener('click', handleLogout);
});

function handleLogout() {
    localStorage.removeItem('prepress_token');
    authToken = null;
    knownScriptIds = [];
    serverScripts = [];
    localScripts = [];
    renamedScripts = {};
    localStorage.removeItem('prepress_known_ids');
    localStorage.removeItem('prepress_renamed_scripts');
    
    // Düzenleme modunu kapat
    isEditMode = false;
    document.body.classList.remove('edit-mode-active');
    if (editModeBanner) editModeBanner.classList.add('hidden');
    if (btnEditMode) {
        btnEditMode.classList.add('hidden');
        btnEditMode.classList.remove('active');
    }

    moduleGrid.innerHTML = '';
    moduleGrid.classList.add('hidden');
    groupedContainer.innerHTML = '';
    groupedContainer.classList.add('hidden');
    filterControls.classList.add('hidden');
    btnSettings.classList.add('hidden');
    settingsModal.classList.add('hidden');
    btnLogout.classList.add('hidden');
    authSection.classList.remove('hidden');
    if (offlineBanner) offlineBanner.classList.add('hidden');
    hideSyncBadge();
    stopPolling();
    inputLicense.value = 'DEMO-PREPRESS-2026';
    loginError.innerText = '';
    showToast("Oturumunuz kapatıldı.", "info");
}

async function handleLogin() {
    const licenseKey = inputLicense.value.trim();
    if (!licenseKey) {
        loginError.innerText = "Lütfen bir lisans anahtarı girin.";
        return;
    }

    loginError.innerText = "Bağlanıyor...";
    
    // Render free sunucusunun ilk uyandırılma süresi için 3 saniye sonra açıklama göster
    const wakeUpTimer = setTimeout(() => {
        loginError.innerText = "Sunucu uyandırılıyor, lütfen bekleyin (İlk bağlantı 1-2 dakika sürebilir)...";
    }, 3000);
    
    try {
        const res = await fetch(`${SERVER_URL}/auth/verify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseKey, hardwareId: machineId })
        });
        
        clearTimeout(wakeUpTimer);
        const data = await res.json();

        if (res.ok && data.token) {
            authToken = data.token;
            localStorage.setItem('prepress_token', authToken);
            loginError.innerText = "";
            showToast(`Hoş geldiniz, ${data.user?.fullName || 'Kullanıcı'}!`, "success");
            
            if (filterControls) filterControls.classList.remove('hidden');
            if (btnSettings) btnSettings.classList.remove('hidden');
            if (btnEditMode) btnEditMode.classList.remove('hidden');
            
            fetchScripts();
        } else {
            loginError.innerText = data.error || "Giriş başarısız.";
            showToast(data.error || "Giriş başarısız.", "error");
        }
    } catch (error) {
        clearTimeout(wakeUpTimer);
        loginError.innerText = "Sunucuya bağlanılamadı.";
        showToast("Sunucuya bağlanılamadı. Lütfen bağlantınızı kontrol edin.", "error", 6000);
    }
}

async function fetchScripts() {
    if (!authToken) return;

    btnSync.classList.add('syncing');

    // Uzantı güncellemelerini kontrol et
    checkForClientUpdates();

    try {
        const res = await fetch(`${SERVER_URL}/scripts/sync`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (!res.ok) {
            if (res.status === 401 || res.status === 403) {
                localStorage.removeItem('prepress_token');
                authToken = null;
                isEditMode = false;
                document.body.classList.remove('edit-mode-active');
                if (editModeBanner) editModeBanner.classList.add('hidden');
                if (btnEditMode) btnEditMode.classList.add('hidden');
                
                authSection.classList.remove('hidden');
                moduleGrid.classList.add('hidden');
                groupedContainer.classList.add('hidden');
                filterControls.classList.add('hidden');
                btnSettings.classList.add('hidden');
                btnLogout.classList.add('hidden');
                loginError.innerText = "Oturum süresi doldu veya erişim reddedildi.";
                showToast("Oturum süreniz doldu. Lütfen tekrar giriş yapın.", "warning", 5000);
                stopPolling();
            }
            btnSync.classList.remove('syncing');
            return;
        }

        const data = await res.json();
        if (data.scripts) {
            serverScripts = data.scripts;

            // Cache'e kaydet
            if (offlineUtils) {
                offlineUtils.saveScriptsToCache(data.scripts);
                data.scripts.forEach(async (script) => {
                    try {
                        const dlRes = await fetch(`${SERVER_URL}/scripts/download/${script.id}`, {
                            headers: { 'Authorization': `Bearer ${authToken}` }
                        });
                        if (dlRes.ok) {
                            const dlBuffer = Buffer.from(await dlRes.arrayBuffer());
                            offlineUtils.cacheScriptBuffer(script.id, dlBuffer);
                        }
                    } catch(e) {}
                });
            }

            // Bilinen ID'leri güncelle
            knownScriptIds = data.scripts.map(s => s.id);
            localStorage.setItem('prepress_known_ids', JSON.stringify(knownScriptIds));

            authSection.classList.add('hidden');
            btnLogout.classList.remove('hidden');
            if (btnEditMode) btnEditMode.classList.remove('hidden');
            if (offlineBanner) offlineBanner.classList.add('hidden');

            if (settings.showLocal) {
                await fetchLocalScripts();
            } else {
                applyFiltersAndRender();
            }

            // Arka plan yoklamasını başlat
            startPolling();
        }
    } catch (error) {
        console.error("Fetch Scripts Error:", error);
        if (offlineUtils) {
            const offlineData = offlineUtils.loadScriptsFromCache();
            if (offlineData.error) {
                loginError.innerText = offlineData.error;
            } else if (offlineData.scripts) {
                serverScripts = offlineData.scripts;
                authSection.classList.add('hidden');
                btnLogout.classList.remove('hidden');
                if (btnEditMode) btnEditMode.classList.remove('hidden');
                
                if (offlineBanner) {
                    offlineBanner.classList.remove('hidden');
                }
                showToast("Çevrimdışı mod aktif. Önbellekteki veriler gösteriliyor.", "warning", 5000);
                
                if (settings.showLocal) {
                    await fetchLocalScripts();
                } else {
                    applyFiltersAndRender();
                }
            }
        }
    } finally {
        btnSync.classList.remove('syncing');
    }
}

// =============================================
// ARKA PLAN YOKLAMA (POLLING)
// =============================================
function startPolling() {
    stopPolling();
    pollingInterval = setInterval(checkForNewModules, POLL_INTERVAL_MS);
}

function stopPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
    }
}

async function checkForNewModules() {
    if (!authToken) return;
    
    try {
        const res = await fetch(`${SERVER_URL}/scripts/sync`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });

        if (!res.ok) return;

        const data = await res.json();
        if (data.scripts) {
            // Yeni modülleri bul (ID listemizde olmayanlar)
            const newModules = data.scripts.filter(s => !knownScriptIds.includes(s.id));

            // Güncellenen modülleri bul (mevcutlardan herhangi bir alanı değişenler)
            const updatedModules = data.scripts.filter(s => {
                const existing = serverScripts.find(ex => ex.id === s.id);
                if (existing) {
                    return existing.fileHash !== s.fileHash || 
                           existing.version !== s.version || 
                           existing.name !== s.name || 
                           existing.description !== s.description ||
                           existing.icon !== s.icon ||
                           existing.extensionId !== s.extensionId;
                }
                return false;
            });

            if (newModules.length > 0 || updatedModules.length > 0) {
                showSyncBadge();
                let toastMsg = '';
                if (newModules.length > 0 && updatedModules.length > 0) {
                    toastMsg = `${newModules.length} yeni modül ve ${updatedModules.length} güncelleme mevcut! Yenile butonuna basarak güncelleyin.`;
                } else if (newModules.length > 0) {
                    toastMsg = `${newModules.length} yeni modül mevcut! Yenile butonuna basarak güncelleyin.`;
                } else {
                    toastMsg = `${updatedModules.length} modül güncellemesi mevcut! Yenile butonuna basarak güncelleyin.`;
                }
                showToast(toastMsg, "info", 6000);
            }
        }
    } catch (e) {
        // Sessizce devam et
    }
}

// =============================================
// FILTRELEME VE RENDER TETIKLEYICISI
// =============================================
function applyFiltersAndRender() {
    let allScripts = [...serverScripts, ...localScripts];

    // 1. Arama Filtresi
    const query = currentFilters.search.trim().toLowerCase();
    if (query) {
        allScripts = allScripts.filter(s => {
            const displayName = renamedScripts[s.id] || s.name;
            return displayName.toLowerCase().includes(query) || s.name.toLowerCase().includes(query);
        });
    }

    // 2.5 Gizlilik Filtresi (Düzenleme modunda değilsek gizlenenleri tamamen uçur)
    if (!isEditMode) {
        allScripts = allScripts.filter(s => !hiddenScriptIds.includes(s.id));
    }

    // 3. Sıralama Mantığı (Sadece özel sürükle-bırak sıralaması)
    const orderStr = localStorage.getItem('module-grid');
    if (orderStr) {
        const orderArray = orderStr.split('|');
        allScripts.sort((a, b) => {
            const idxA = orderArray.indexOf(a.id);
            const idxB = orderArray.indexOf(b.id);
            if (idxA !== -1 && idxB !== -1) return idxA - idxB;
            if (idxA !== -1) return -1;
            if (idxB !== -1) return 1;
            return 0;
        });
    }

    // 4. Görünüm Render Mantığı
    if (currentFilters.layout === 'FLAT') {
        moduleGrid.classList.remove('hidden');
        groupedContainer.classList.add('hidden');
        renderFlatGrid(allScripts);
    } else {
        moduleGrid.classList.add('hidden');
        groupedContainer.classList.remove('hidden');
        renderGroupedGrid(allScripts);
    }
}

// =============================================
// GRID ELEMANI OLUŞTURUCU
// =============================================
function createGridItem(script) {
    const item = document.createElement('div');
    item.className = 'grid-item';
    item.setAttribute('data-id', script.id);
    
    // Tür sınıfını ekle (Styling için)
    if (script.type) {
        item.classList.add('type-' + script.type.toLowerCase());
    }
    
    // Gizlenmişse stili uygula
    if (hiddenScriptIds.includes(script.id)) {
        item.classList.add('is-hidden');
    }

    // 1. Sürükleme Noktası (Drag Handle)
    const dragHandle = document.createElement('div');
    dragHandle.className = 'item-drag-handle';
    dragHandle.innerHTML = `
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <circle cx="9" cy="5" r="1.5" fill="currentColor"/>
            <circle cx="9" cy="12" r="1.5" fill="currentColor"/>
            <circle cx="9" cy="19" r="1.5" fill="currentColor"/>
            <circle cx="15" cy="5" r="1.5" fill="currentColor"/>
            <circle cx="15" cy="12" r="1.5" fill="currentColor"/>
            <circle cx="15" cy="19" r="1.5" fill="currentColor"/>
        </svg>
    `;
    item.appendChild(dragHandle);

    // 2. Göz (Gizle/Göster) Butonu
    const visibilityBtn = document.createElement('button');
    visibilityBtn.className = 'item-visibility-btn';
    
    const isHidden = hiddenScriptIds.includes(script.id);
    visibilityBtn.title = isHidden ? "Modülü Göster" : "Modülü Gizle";
    visibilityBtn.innerHTML = isHidden ? `
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
            <line x1="1" y1="1" x2="23" y2="23"/>
        </svg>
    ` : `
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
            <circle cx="12" cy="12" r="3"/>
        </svg>
    `;
    
    visibilityBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleHideModule(script.id);
    });
    item.appendChild(visibilityBtn);

    // 3. İkon
    const displayName = renamedScripts[script.id] || script.name;
    const icon = document.createElement('div');
    icon.className = 'item-icon';
    let cleanedIcon = '';
    if (script.icon) {
        const startIdx = script.icon.indexOf('<svg');
        if (startIdx !== -1) {
            cleanedIcon = script.icon.substring(startIdx).trim();
        }
    }
    if (cleanedIcon) {
        icon.innerHTML = cleanedIcon;
    } else {
        icon.innerText = displayName.normalize('NFC').charAt(0).toUpperCase();
    }
    item.appendChild(icon);

    // 4. İsim
    const name = document.createElement('div');
    name.className = 'item-name';
    name.innerText = displayName;
    
    if (isEditMode) {
        name.contentEditable = 'true';
        name.setAttribute('spellcheck', 'false');
        
        name.addEventListener('click', (e) => {
            e.stopPropagation();
        });
        
        name.addEventListener('blur', () => {
            const newName = name.innerText.trim();
            if (newName && newName !== script.name) {
                renamedScripts[script.id] = newName;
                localStorage.setItem('prepress_renamed_scripts', JSON.stringify(renamedScripts));
                if (!cleanedIcon) {
                    icon.innerText = newName.normalize('NFC').charAt(0).toUpperCase();
                }
            } else {
                delete renamedScripts[script.id];
                localStorage.setItem('prepress_renamed_scripts', JSON.stringify(renamedScripts));
                name.innerText = script.name;
                if (!cleanedIcon) {
                    icon.innerText = script.name.normalize('NFC').charAt(0).toUpperCase();
                }
            }
        });
        
        name.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                name.blur();
            }
        });
    }
    
    item.appendChild(name);

    // 5. Tıklama Olayı (Düzenleme modunda script tetiklemeyi engelle)
    item.addEventListener('click', (e) => {
        if (isEditMode) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }
        executeScript(script);
    });

    return item;
}

// =============================================
// FLAT LAYOUT GRID RENDER
// =============================================
function renderFlatGrid(scripts) {
    moduleGrid.innerHTML = '';

    if (currentSortableInstance) {
        currentSortableInstance.destroy();
        currentSortableInstance = null;
    }

    scripts.forEach(script => {
        moduleGrid.appendChild(createGridItem(script));
    });

    // Sadece Sıralama: Düzenleme Modu aktifken SortableJS çalışmalı
    if (isEditMode && typeof Sortable !== 'undefined') {
        currentSortableInstance = new Sortable(moduleGrid, {
            animation: 150,
            ghostClass: 'sortable-ghost',
            group: 'module-grid',
            forceFallback: true,
            fallbackTolerance: 4,
            fallbackOnBody: true,
            supportPointer: false,
            draggable: '.grid-item',
            filter: ".item-visibility-btn",
            onEnd: function () {
                const order = [];
                moduleGrid.querySelectorAll('.grid-item').forEach(el => {
                    order.push(el.getAttribute('data-id'));
                });
                localStorage.setItem('module-grid', order.join('|'));
            }
        });
    }
}

// =============================================
// GROUPED LAYOUT GRID RENDER
// =============================================
let groupSortableInstances = [];

function renderGroupedGrid(scripts) {
    groupedContainer.innerHTML = '';

    // Eski sortable örneklerini temizle
    groupSortableInstances.forEach(inst => {
        try { inst.destroy(); } catch(e){}
    });
    groupSortableInstances = [];

    // Custom gruplarda bulunan tüm script ID'leri
    const customGroupedIds = [];
    customGroups.forEach(g => {
        if (g.scriptIds && Array.isArray(g.scriptIds)) {
            customGroupedIds.push(...g.scriptIds);
        }
    });

    // 1. Genel (Uncategorized Server Scripts) grubu hesapla
    const uncategorizedScripts = scripts.filter(s => s.type !== 'LOCAL' && !customGroupedIds.includes(s.id));

    // 1.5 Yerel Scriptler (Bilgisayarım) grubu
    const localScriptsList = scripts.filter(s => s.type === 'LOCAL' && !customGroupedIds.includes(s.id));

    // Render edilecek bölümler listesini oluştur
    const sectionsToRender = [];

    if (uncategorizedScripts.length > 0 || isEditMode) {
        sectionsToRender.push({
            id: 'uncategorized',
            name: 'Genel Modüller',
            scripts: uncategorizedScripts,
            isSystem: true
        });
    }

    if (settings.showLocal) {
        if (localScriptsList.length > 0 || isEditMode) {
            sectionsToRender.push({
                id: 'local-scripts',
                name: 'Yerel Scriptler',
                scripts: localScriptsList,
                isSystem: true
            });
        }
    }

    customGroups.forEach(group => {
        const groupScripts = scripts.filter(s => group.scriptIds && group.scriptIds.includes(s.id));
        if (groupScripts.length > 0 || isEditMode) {
            sectionsToRender.push({
                id: group.id,
                name: group.name,
                scripts: groupScripts,
                isSystem: false,
                groupObj: group
            });
        }
    });

    // Grupları kaydedilen sıralarına göre sırala
    const groupOrderStr = localStorage.getItem('prepress_group_order');
    if (groupOrderStr) {
        const groupOrderArray = groupOrderStr.split('|');
        sectionsToRender.sort((a, b) => {
            const idxA = groupOrderArray.indexOf(a.id);
            const idxB = groupOrderArray.indexOf(b.id);
            if (idxA !== -1 && idxB !== -1) return idxA - idxB;
            if (idxA !== -1) return -1;
            if (idxB !== -1) return 1;
            return 0;
        });
    }

    // Bölümleri render et
    sectionsToRender.forEach(sec => {
        const section = document.createElement('div');
        section.className = 'group-section';
        section.setAttribute('data-group-id', sec.id);

        const title = document.createElement('h3');
        title.className = 'group-title';
        title.setAttribute('lang', 'en');

        if (sec.isSystem) {
            title.innerHTML = `
                <span class="group-title-text">${sec.name}</span>
                <span style="font-size:10px; opacity:0.5; margin-left:6px; font-weight:normal;">(${sec.scripts.length})</span>
            `;
        } else {
            // Silme butonu SVG
            const deleteSvg = `
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                </svg>
            `;

            title.innerHTML = `
                <span class="group-title-text" contenteditable="${isEditMode ? 'true' : 'false'}">${sec.name}</span>
                <button class="group-delete-btn" title="Grubu Sil">${deleteSvg}</button>
            `;

            // Başlık düzenleme listener'ları
            const titleTextEl = title.querySelector('.group-title-text');
            titleTextEl.addEventListener('blur', () => {
                saveCustomGroupsFromDOM();
            });
            titleTextEl.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    titleTextEl.blur();
                }
            });

            // Silme butonu listener'ı
            const deleteBtn = title.querySelector('.group-delete-btn');
            deleteBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                deleteGroup(sec.id);
            });
        }

        const grid = document.createElement('div');
        grid.className = 'grid-container';

        sec.scripts.forEach(script => {
            grid.appendChild(createGridItem(script));
        });

        section.appendChild(title);
        section.appendChild(grid);
        groupedContainer.appendChild(section);
    });

    // 3. Sıralama ve Sürükleme (SortableJS) Tanımlamaları
    if (isEditMode && typeof Sortable !== 'undefined') {
        // Her bir grubun ızgarasını (grid-container) sürükleme grubu yap
        groupedContainer.querySelectorAll('.group-section .grid-container').forEach(gridEl => {
            const inst = new Sortable(gridEl, {
                group: 'shared-modules', // Gruplar arası sürüklemeyi sağlar
                animation: 150,
                ghostClass: 'sortable-ghost',
                forceFallback: true,
                fallbackTolerance: 4,
                fallbackOnBody: true,
                supportPointer: false,
                draggable: '.grid-item',
                filter: ".item-visibility-btn",
                onEnd: function() {
                    saveCustomGroupsFromDOM();
                }
            });
            groupSortableInstances.push(inst);
        });

        // Grupların kendisini de dikey olarak sıralanabilir yap
        const groupInst = new Sortable(groupedContainer, {
            animation: 150,
            handle: '.group-title', // Sadece başlığından tutarak grup sıralanabilir
            draggable: '.group-section',
            forceFallback: true,
            fallbackTolerance: 4,
            fallbackOnBody: true,
            supportPointer: false,
            filter: ".group-title-text, .group-delete-btn",
            preventOnFilter: false,
            onEnd: function() {
                saveCustomGroupsFromDOM();
            }
        });
        groupSortableInstances.push(groupInst);
    }
}

// =============================================
// KİŞİSELLEŞTİRME VE ÖZEL GRUPLAMA YÖNETİMİ
// =============================================
function initEditModeControls() {
    if (btnEditMode) {
        btnEditMode.addEventListener('click', () => {
            if (currentFilters.layout === 'FLAT') {
                showToast("Düzenleme modu yalnızca Kategori (Grup) görünümünde kullanılabilir. Lütfen arama yanındaki buton ile Kategori görünümüne geçin.", "warning", 5000);
                return;
            }
            toggleEditMode();
        });
    }

    if (btnEditDone) {
        btnEditDone.addEventListener('click', () => {
            toggleEditMode();
        });
    }

    if (btnEditReset) {
        btnEditReset.addEventListener('click', () => {
            resetCustomizations();
        });
    }

    if (btnEditAddGroup) {
        btnEditAddGroup.addEventListener('click', () => {
            createNewGroup();
        });
    }

    // Gömülü uygulama görünümünü kapat
    if (btnCloseApp) {
        btnCloseApp.addEventListener('click', () => {
            if (appViewer) appViewer.classList.add('hidden');
            if (appIframe) appIframe.src = 'about:blank'; // Belleği boşalt
            showToast("Hub ana ekranına dönüldü.", "info");
        });
    }
}

function toggleEditMode() {
    isEditMode = !isEditMode;
    
    if (isEditMode) {
        document.body.classList.add('edit-mode-active');
        if (editModeBanner) editModeBanner.classList.remove('hidden');
        if (btnEditMode) btnEditMode.classList.add('active');
        showToast("Kişiselleştirme Modu Aktif.", "info", 3000);
    } else {
        document.body.classList.remove('edit-mode-active');
        if (editModeBanner) editModeBanner.classList.add('hidden');
        if (btnEditMode) btnEditMode.classList.remove('active');
        showToast("Kişiselleştirmeler kaydedildi.", "success");
    }
    
    applyFiltersAndRender();
}

function createNewGroup() {
    const newGroup = {
        id: 'group-' + Date.now(),
        name: 'Yeni Grup ' + (customGroups.length + 1),
        scriptIds: []
    };
    
    customGroups.push(newGroup);
    localStorage.setItem('prepress_custom_groups', JSON.stringify(customGroups));
    
    applyFiltersAndRender();
    
    // Yeni oluşturulan grubun ismini hemen düzenlemesi için odağı oraya alalım
    setTimeout(() => {
        const sections = groupedContainer.querySelectorAll('.group-section');
        if (sections.length > 0) {
            const lastSection = sections[sections.length - 1];
            const titleEl = lastSection.querySelector('.group-title-text');
            if (titleEl) {
                titleEl.focus();
                // Metnin tamamını seçelim kolaylık olması için
                const range = document.createRange();
                range.selectNodeContents(titleEl);
                const sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
            }
        }
    }, 100);
}

function deleteGroup(groupId) {
    customGroups = customGroups.filter(g => g.id !== groupId);
    localStorage.setItem('prepress_custom_groups', JSON.stringify(customGroups));
    applyFiltersAndRender();
}

function toggleHideModule(scriptId) {
    const index = hiddenScriptIds.indexOf(scriptId);
    if (index === -1) {
        hiddenScriptIds.push(scriptId);
    } else {
        hiddenScriptIds.splice(index, 1);
    }
    
    localStorage.setItem('prepress_hidden_ids', JSON.stringify(hiddenScriptIds));
    applyFiltersAndRender();
}

async function resetCustomizations() {
    const confirmReset = await showConfirm("Tüm yerleşimi, grupları, gizlenen modülleri ve değiştirdiğiniz script isimlerini sıfırlamak istediğinize emin misiniz?", "Sıfırlama Onayı");
    if (!confirmReset) return;

    localStorage.removeItem('prepress_hidden_ids');
    localStorage.removeItem('prepress_custom_groups');
    localStorage.removeItem('prepress_group_order');
    localStorage.removeItem('module-grid');
    localStorage.removeItem('prepress_renamed_scripts');
    
    hiddenScriptIds = [];
    customGroups = [];
    renamedScripts = {};
    
    applyFiltersAndRender();
    showToast("Tüm özelleştirmeler ve isimler sıfırlandı.", "info");
}

function saveCustomGroupsFromDOM() {
    const newGroups = [];
    const globalOrder = [];
    const groupOrder = [];
    
    // Tüm grid-item elemanlarının sırasını kaydet (Genel ve Yerel dahil)
    groupedContainer.querySelectorAll('.grid-item').forEach(item => {
        const id = item.getAttribute('data-id');
        if (id) globalOrder.push(id);
    });
    localStorage.setItem('module-grid', globalOrder.join('|'));
    
    groupedContainer.querySelectorAll('.group-section').forEach(section => {
        const groupId = section.getAttribute('data-group-id');
        if (!groupId) return;
        groupOrder.push(groupId);
        
        if (groupId === 'uncategorized' || groupId === 'local-scripts') return;
        
        const titleTextEl = section.querySelector('.group-title-text');
        const groupName = titleTextEl ? titleTextEl.innerText.trim() : 'Yeni Grup';
        
        const scriptIds = [];
        section.querySelectorAll('.grid-item').forEach(item => {
            scriptIds.push(item.getAttribute('data-id'));
        });
        
        newGroups.push({
            id: groupId,
            name: groupName,
            scriptIds: scriptIds
        });
    });
    customGroups = newGroups;
    localStorage.setItem('prepress_custom_groups', JSON.stringify(customGroups));
    localStorage.setItem('prepress_group_order', groupOrder.join('|'));
}

function openAppInViewer(url) {
    if (appIframe && appViewer) {
        appIframe.src = url;
        appViewer.classList.remove('hidden');
        
        // Iframe yüklendiğinde ve yüklenirken Node.js ve CEP API'lerini enjekte et
        const injectGlobals = () => {
            try {
                const iframeWin = appIframe.contentWindow;
                if (iframeWin) {
                    iframeWin.require = window.require;
                    iframeWin.module = window.module;
                    iframeWin.exports = window.exports;
                    iframeWin.__dirname = window.__dirname;
                    iframeWin.process = window.process;
                    iframeWin.Buffer = window.Buffer;
                    iframeWin.csInterface = window.csInterface;
                    iframeWin.cep = window.cep;
                    iframeWin.__adobe_cep__ = window.__adobe_cep__;
                    
                    if (typeof iframeWin.CSInterface === 'undefined' && typeof window.CSInterface !== 'undefined') {
                        iframeWin.CSInterface = window.CSInterface;
                    }
                }
            } catch (e) {}
        };
        
        // Iframe onload listener
        appIframe.addEventListener('load', injectGlobals);
        
        // Polling ile erkenden enjekte etmeye çalış
        let injectCount = 0;
        const injectInterval = setInterval(() => {
            injectGlobals();
            injectCount++;
            if (injectCount > 150) { // 3 saniye boyunca dene
                clearInterval(injectInterval);
            }
        }, 20);
    }
}

function getExtensionHtmlPath(safeId) {
    if (typeof require === 'undefined') return null;
    
    let extensionsDir;
    if (os.platform() === 'win32') {
        extensionsDir = path.join(process.env.APPDATA || '', 'Adobe', 'CEP', 'extensions');
    } else {
        extensionsDir = path.join(os.homedir(), 'Library', 'Application Support', 'Adobe', 'CEP', 'extensions');
    }
    
    const targetDir = path.join(extensionsDir, safeId);
    
    // Klasörün varlığını kontrol et
    if (!fs.existsSync(targetDir)) return null;
    
    // Yaygın HTML yollarını kontrol et (Iframe içi relative link yapısıyla)
    const paths = [
        { path: path.join(targetDir, 'index.html'), rel: `../../${safeId}/index.html` },
        { path: path.join(targetDir, 'client', 'index.html'), rel: `../../${safeId}/client/index.html` },
        { path: path.join(targetDir, 'html', 'index.html'), rel: `../../${safeId}/html/index.html` }
    ];
    
    for (let p of paths) {
        if (fs.existsSync(p.path)) {
            return p.rel;
        }
    }
    
    return null;
}

function getExtensionIdFromManifest(safeId) {
    if (typeof require === 'undefined') return null;
    
    let extensionsDir;
    if (os.platform() === 'win32') {
        extensionsDir = path.join(process.env.APPDATA || '', 'Adobe', 'CEP', 'extensions');
    } else {
        extensionsDir = path.join(os.homedir(), 'Library', 'Application Support', 'Adobe', 'CEP', 'extensions');
    }
    
    const manifestPath = path.join(extensionsDir, safeId, 'CSXS', 'manifest.xml');
    if (!fs.existsSync(manifestPath)) return null;
    
    try {
        const content = fs.readFileSync(manifestPath, 'utf8');
        // Extension Id="xxxx" değerini yakala
        const match = content.match(/<Extension\s+Id="([^"]+)"/);
        if (match && match[1]) {
            return match[1];
        }
    } catch (e) {
        console.error("Manifest okuma hatası:", e);
    }
    return null;
}

// Sunucuya log kaydı gönder
async function sendClientLog(scriptId, action, status, duration = null, errorDetails = null) {
    try {
        if (!authToken) return;
        await fetch(`${SERVER_URL}/scripts/log`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                scriptId,
                action,
                status,
                duration: duration !== null ? Math.round(duration) : null,
                errorDetails: errorDetails || null
            })
        });
    } catch (e) {
        console.error("Log gönderme hatası:", e);
    }
}

// =============================================
// SCRIPT VE ZXP ÇALIŞTIRMA
// =============================================
async function executeScript(scriptData) {
    const displayName = renamedScripts[scriptData.id] || scriptData.name;
    // 1. Yerel scriptleri doğrudan Illustrator içinde çalıştır
    if (scriptData.type === 'LOCAL') {
        const safePath = scriptData.path.replace(/\\/g, '/');
        const evalStr = `runScriptFile('${safePath}')`;
        csInterface.evalScript(evalStr, (res) => {
            console.log("Local Script Result:", res);
            if (res && res.startsWith("ERROR:")) {
                showToast("Script hatası: " + res.substring(6), "error");
            } else {
                showToast(`"${displayName}" başarıyla çalıştırıldı.`, "success");
            }
        });
        return;
    }

    // 2. JSX Modülü
    if (scriptData.type === 'JSX') {
        const startTime = Date.now();
        try {
            let buffer;
            if (offlineUtils) {
                buffer = offlineUtils.getScriptBufferFromCache(scriptData.id);
            }
            if (!buffer) {
                const response = await fetch(`${SERVER_URL}/scripts/download/${scriptData.id}`, {
                    headers: { 'Authorization': `Bearer ${authToken}` }
                });
                
                if (!response.ok) throw new Error("Dosya indirilemedi");
                
                const arrayBuffer = await response.arrayBuffer();
                buffer = Buffer.from(arrayBuffer);
            }
            
            const decryptedBuffer = cryptoUtils.decryptBuffer(buffer);
            
            const currentHash = cryptoUtils.calculateHash(decryptedBuffer);
            if (currentHash !== scriptData.fileHash) {
                console.warn("Hash uyuşmazlığı tespit edildi! Dosya bozulmuş olabilir.");
            }
            
            const tempDir = path.join(os.tmpdir(), 'prepress_core_scripts');
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }
            const tempFile = path.join(tempDir, `${scriptData.id}.jsx`);
            fs.writeFileSync(tempFile, decryptedBuffer);
            
            const safePath = tempFile.replace(/\\/g, '/');
            const evalStr = `runScriptFile('${safePath}')`;
            
            csInterface.evalScript(evalStr, (res) => {
                console.log("Script Result:", res);
                const duration = Date.now() - startTime;
                if (res && res.startsWith("ERROR:")) {
                    const errMsg = res.substring(6);
                    showToast("Script hatası: " + errMsg, "error");
                    sendClientLog(scriptData.id, 'EXECUTE', 'FAILED', duration, errMsg);
                } else {
                    sendClientLog(scriptData.id, 'EXECUTE', 'SUCCESS', duration);
                }
                try { fs.unlinkSync(tempFile); } catch(e){}
            });
            
        } catch (error) {
            const duration = Date.now() - startTime;
            showToast("Script çalıştırma hatası: " + error.message, "error", 6000);
            console.error(error);
            sendClientLog(scriptData.id, 'EXECUTE', 'FAILED', duration, error.message);
        }

    // 3. ZXP Modülü
    } else if (scriptData.type === 'ZXP') {
        const localHtmlPath = getExtensionHtmlPath(scriptData.id);

        // Arayüz içi çalıştırma devre dışı bırakıldığı için, kuruluysa her zaman ayrı pencere (popup) olarak aç
        if (localHtmlPath) {
            // Önce yerel manifestodan Extension ID'sini oku, yoksa veritabanındaki değeri kullan
            const extId = getExtensionIdFromManifest(scriptData.id) || scriptData.extensionId;
            if (extId) {
                showToast(`"${displayName}" ayrı pencerede açılıyor...`, "success", 3000);
                try {
                    csInterface.requestOpenExtension(extId, "");
                    sendClientLog(scriptData.id, 'EXECUTE', 'SUCCESS');
                } catch (e) {
                    showToast("Eklenti açılırken hata oluştu: " + e.message, "error");
                    sendClientLog(scriptData.id, 'EXECUTE', 'FAILED', null, e.message);
                }
                return;
            }
        }

        // Değilse indir ve sessiz kur
        showToast(`"${displayName}" eklentisi kuruluyor...`, "info", 3000);
        const startTime = Date.now();

        try {
            let buffer;
            if (offlineUtils) {
                buffer = offlineUtils.getScriptBufferFromCache(scriptData.id);
            }
            if (!buffer) {
                const response = await fetch(`${SERVER_URL}/scripts/download/${scriptData.id}`, {
                    headers: { 'Authorization': `Bearer ${authToken}` }
                });
                if (!response.ok) throw new Error("ZXP dosyası indirilemedi");
                buffer = Buffer.from(await response.arrayBuffer());
            }

            const decryptedBuffer = cryptoUtils.decryptBuffer(buffer);
            
            const tempDir = path.join(os.tmpdir(), 'prepress_core_scripts');
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
            
            const zxpFile = path.join(tempDir, `${scriptData.id}.zxp`);
            fs.writeFileSync(zxpFile, decryptedBuffer);
            
            if (silentInstallUtils) {
                // Klasör adının benzersiz script ID'si ile eşleşmesi için scriptData.id gönderiyoruz
                await silentInstallUtils.installZXP(zxpFile, scriptData.id);
                const duration = Date.now() - startTime;
                showToast(`"${displayName}" başarıyla kuruldu. Aktif olması için Illustrator'ı yeniden başlatın.`, "success", 7000);
                sendClientLog(scriptData.id, 'INSTALL', 'SUCCESS', duration);
            }
            
            try { fs.unlinkSync(zxpFile); } catch(e){}

        } catch (error) {
            const duration = Date.now() - startTime;
            showToast("ZXP kurulum hatası: " + error.message, "error", 6000);
            console.error(error);
            sendClientLog(scriptData.id, 'INSTALL', 'FAILED', duration, error.message);
        }
    }
}

// =============================================
// KENDI KENDINE GÜNCELLEME (AUTO-UPDATE) ALTYAPISI
// =============================================
const CLIENT_VERSION = '1.0.0';

async function checkForClientUpdates() {
    if (typeof require === 'undefined' || !fs || !path) return;
    
    try {
        // serverUrl'den /api kısmını çıkarıp /updates/version.json ekleyelim
        const baseServerUrl = SERVER_URL.replace(/\/api$/, '');
        const res = await fetch(`${baseServerUrl}/updates/version.json?t=${Date.now()}`);
        if (!res.ok) return; // Dosya yoksa veya sunucu yanıt vermiyorsa atla
        
        const data = await res.json();
        if (data && data.version && isNewerVersion(data.version, CLIENT_VERSION)) {
            const confirmUpdate = await showConfirm(
                `Prepress Core Hub için yeni bir güncelleme mevcut (v${data.version}). Şimdi güncellemek ister misiniz?\n\nDeğişikliklerin uygulanması için panel otomatik olarak yeniden yüklenecektir.`,
                "Güncelleme Mevcut"
            );
            if (confirmUpdate) {
                await performClientUpdate(data.downloadUrl.startsWith('http') ? data.downloadUrl : `${baseServerUrl}${data.downloadUrl}`);
            }
        }
    } catch (e) {
        console.error("Uzantı güncelleme kontrol hatası:", e);
    }
}

function isNewerVersion(latest, current) {
    const l = latest.split('.').map(Number);
    const c = current.split('.').map(Number);
    for (let i = 0; i < Math.max(l.length, c.length); i++) {
        const lVal = l[i] || 0;
        const cVal = c[i] || 0;
        if (lVal > cVal) return true;
        if (lVal < cVal) return false;
    }
    return false;
}

async function performClientUpdate(downloadUrl) {
    showToast("Güncelleme indiriliyor...", "info", 5000);
    try {
        const res = await fetch(downloadUrl);
        if (!res.ok) throw new Error("İndirme hatası");
        
        const buffer = Buffer.from(await res.arrayBuffer());
        
        const extPath = decodeURI(window.__adobe_cep__.getSystemPath("extension"));
        const tmpZipPath = path.join(os.tmpdir(), `prepress_update_${Date.now()}.zip`);
        
        // Geçici ZIP dosyasını yaz
        fs.writeFileSync(tmpZipPath, buffer);
        
        showToast("Güncelleme dosyaları çıkartılıyor...", "info", 3000);
        
        let command;
        if (os.platform() === 'win32') {
            command = `powershell -command "Expand-Archive -Force -Path '${tmpZipPath}' -DestinationPath '${extPath}'"`;
        } else {
            command = `unzip -o "${tmpZipPath}" -d "${extPath}"`;
        }
        
        child_process.exec(command, (error, stdout, stderr) => {
            // Geçici dosyayı sil
            try { fs.unlinkSync(tmpZipPath); } catch(e) {}
            
            if (error) {
                console.error("Güncelleme çıkarma hatası:", error);
                showToast("Güncelleme kurulamadı: " + error.message, "error", 5000);
            } else {
                showToast("Güncelleme başarıyla tamamlandı! Panel yeniden yükleniyor...", "success", 3000);
                setTimeout(() => {
                    window.location.reload();
                }, 1500);
            }
        });
    } catch (err) {
        console.error("Güncelleme indirme hatası:", err);
        showToast("Güncelleme dosyası indirilemedi: " + err.message, "error", 5000);
    }
}

// =============================================
// ILLUSTRATOR TEMA ENTEGRASYONU (THEME SYNC)
// =============================================
function initThemeColor() {
    try {
        // İlk açılışta temayı ayarla
        const hostEnv = csInterface.getHostEnvironment();
        if (hostEnv && hostEnv.appSkinInfo) {
            updateThemeWithAppSkinInfo(hostEnv.appSkinInfo);
        }
        
        // Tema değişimlerini dinle (Illustrator Preferences panelinden parlaklık değişince tetiklenir)
        csInterface.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT, onThemeColorChanged);
    } catch (e) {
        console.error("Tema başlatma hatası:", e);
    }
}

function onThemeColorChanged(event) {
    try {
        const hostEnv = csInterface.getHostEnvironment();
        if (hostEnv && hostEnv.appSkinInfo) {
            updateThemeWithAppSkinInfo(hostEnv.appSkinInfo);
        }
    } catch (e) {
        console.error("Tema değişim işleme hatası:", e);
    }
}

function updateThemeWithAppSkinInfo(appSkinInfo) {
    if (!appSkinInfo) return;
    
    const panelBgColor = appSkinInfo.panelBackgroundColor.color;
    
    const bgRed = Math.round(panelBgColor.red);
    const bgGreen = Math.round(panelBgColor.green);
    const bgBlue = Math.round(panelBgColor.blue);
    
    // Parlaklık değerini (brightness) hesaplayalım (0-255 arası)
    const brightness = (bgRed * 299 + bgGreen * 587 + bgBlue * 114) / 1000;
    const isDark = brightness < 128;
    
    const root = document.documentElement;
    
    // Ortak renkleri set edelim (Arka plan doğrudan Illustrator'ın kendi rengidir)
    root.style.setProperty('--bg-base', `rgb(${bgRed}, ${bgGreen}, ${bgBlue})`);
    
    if (isDark) {
        document.body.classList.remove('light-theme');
        document.body.classList.add('dark-theme');
        
        // Koyu Temalar (Koyu ve Orta Koyu Illustrator modları için)
        // Kartlar ve diğer paneller için biraz daha açık ton
        root.style.setProperty('--bg-panel', `rgb(${Math.min(bgRed + 12, 255)}, ${Math.min(bgGreen + 12, 255)}, ${Math.min(bgBlue + 12, 255)})`);
        // Header için biraz daha koyu ton
        root.style.setProperty('--bg-header', `rgb(${Math.max(bgRed - 8, 0)}, ${Math.max(bgGreen - 8, 0)}, ${Math.max(bgBlue - 8, 0)})`);
        
        root.style.setProperty('--text-primary', '#cccccc');
        root.style.setProperty('--text-secondary', '#999999');
        root.style.setProperty('--text-heading', '#ffffff');
        root.style.setProperty('--text-footer', 'rgba(255, 255, 255, 0.3)');
        
        root.style.setProperty('--border', `rgb(${Math.min(bgRed + 22, 255)}, ${Math.min(bgGreen + 22, 255)}, ${Math.min(bgBlue + 22, 255)})`);
        
        root.style.setProperty('--bg-hover', `rgb(${Math.min(bgRed + 24, 255)}, ${Math.min(bgGreen + 24, 255)}, ${Math.min(bgBlue + 24, 255)})`);
        root.style.setProperty('--bg-hover-overlay', 'rgba(255, 255, 255, 0.08)');
    } else {
        document.body.classList.remove('dark-theme');
        document.body.classList.add('light-theme');
        
        // Açık Temalar (Açık ve Orta Açık Illustrator modları için)
        // Kartlar ve diğer paneller için biraz daha koyu ton (derinlik katmak için)
        root.style.setProperty('--bg-panel', `rgb(${Math.max(bgRed - 12, 0)}, ${Math.max(bgGreen - 12, 0)}, ${Math.max(bgBlue - 12, 0)})`);
        // Header için biraz daha koyu ton
        root.style.setProperty('--bg-header', `rgb(${Math.max(bgRed - 20, 0)}, ${Math.max(bgGreen - 20, 0)}, ${Math.max(bgBlue - 20, 0)})`);
        
        root.style.setProperty('--text-primary', '#222222');
        root.style.setProperty('--text-secondary', '#666666');
        root.style.setProperty('--text-heading', '#000000');
        root.style.setProperty('--text-footer', 'rgba(0, 0, 0, 0.45)');
        
        root.style.setProperty('--border', `rgb(${Math.max(bgRed - 25, 0)}, ${Math.max(bgGreen - 25, 0)}, ${Math.max(bgBlue - 25, 0)})`);
        
        root.style.setProperty('--bg-hover', `rgb(${Math.max(bgRed - 22, 0)}, ${Math.max(bgGreen - 22, 0)}, ${Math.max(bgBlue - 22, 0)})`);
        root.style.setProperty('--bg-hover-overlay', 'rgba(0, 0, 0, 0.06)');
    }
}

// Özel ve şık onay (confirm) modalı oluşturma fonksiyonu
function showConfirm(message, title = "Onay", okText = "Tamam", cancelText = "Vazgeç") {
    return new Promise((resolve) => {
        const modal = document.createElement('div');
        modal.id = 'custom-confirm-modal';
        modal.className = 'modal';
        modal.style.zIndex = '11000'; // Diğer tüm bileşenlerin (iframe dahil) üzerinde olması için
        
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button id="custom-confirm-close" class="close-btn">&times;</button>
                </div>
                <div class="modal-body" style="gap: 16px;">
                    <p style="margin: 0; font-size: 11.5px; line-height: 1.5; color: var(--text-primary); text-align: left; white-space: pre-line;">${message}</p>
                    <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 8px;">
                        <button id="custom-confirm-cancel" class="btn-primary" style="background: transparent; border: 1px solid var(--border); color: var(--text-primary); padding: 6px 14px; font-size: 11px; border-radius: 4px; font-weight: 500; cursor: pointer; transition: all 0.2s;">${cancelText}</button>
                        <button id="custom-confirm-ok" class="btn-primary" style="padding: 6px 14px; font-size: 11px; border-radius: 4px; font-weight: 500; border: none; cursor: pointer;">${okText}</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        const closeBtn = modal.querySelector('#custom-confirm-close');
        const cancelBtn = modal.querySelector('#custom-confirm-cancel');
        const okBtn = modal.querySelector('#custom-confirm-ok');
        
        function handleKeyDown(e) {
            if (e.key === 'Escape') {
                cleanup();
                resolve(false);
            } else if (e.key === 'Enter') {
                cleanup();
                resolve(true);
            }
        }
        
        function cleanup() {
            document.removeEventListener('keydown', handleKeyDown);
            modal.remove();
        }
        
        closeBtn.addEventListener('click', () => {
            cleanup();
            resolve(false);
        });
        
        cancelBtn.addEventListener('click', () => {
            cleanup();
            resolve(false);
        });
        
        okBtn.addEventListener('click', () => {
            cleanup();
            resolve(true);
        });
        
        document.addEventListener('keydown', handleKeyDown);
    });
}

