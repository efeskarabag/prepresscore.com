const crypto = require('crypto');

const ALGORITHM = 'aes-256-cbc';
// Güvenlik gereği, gerçekte bu değer çevre değişkeninden veya güvenli bir vault'tan gelmelidir.
// Ancak şimdilik sistemin çalışması için backend'deki varsayılan anahtarla eşleştirildi.
const SECRET_KEY = 'super_secret_prepress_key_2026';

function getValidKey() {
    return crypto.createHash('sha256').update(String(SECRET_KEY)).digest('base64').substring(0, 32);
}

function decryptBuffer(buffer) {
    try {
        const iv = buffer.subarray(0, 16);
        const encryptedText = buffer.subarray(16);
        const decipher = crypto.createDecipheriv(ALGORITHM, Buffer.from(getValidKey()), iv);
        const decrypted = Buffer.concat([decipher.update(encryptedText), decipher.final()]);
        return decrypted;
    } catch (e) {
        console.error("Decryption Error:", e);
        throw new Error("Dosya şifresi çözülemedi. Bozuk veya geçersiz dosya.");
    }
}

function calculateHash(buffer) {
    return crypto.createHash('sha256').update(buffer).digest('hex');
}

module.exports = {
    decryptBuffer,
    calculateHash
};
