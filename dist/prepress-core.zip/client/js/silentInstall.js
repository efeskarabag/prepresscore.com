const child_process = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

function installZXP(zxpFilePath, extensionName) {
    return new Promise((resolve, reject) => {
        // Eklenti adı boşluk içeriyorsa alt tire ile değiştirelim ki klasör adı temiz olsun
        const safeName = (extensionName || path.basename(zxpFilePath, '.zxp')).replace(/[^a-zA-Z0-9_-]/g, '_');
        
        let extensionsDir;
        if (os.platform() === 'win32') {
            extensionsDir = path.join(process.env.APPDATA || '', 'Adobe', 'CEP', 'extensions');
        } else {
            extensionsDir = path.join(os.homedir(), 'Library', 'Application Support', 'Adobe', 'CEP', 'extensions');
        }

        // ZXP'nin çıkarılacağı hedef klasör
        const targetDir = path.join(extensionsDir, safeName);

        // Hedef klasör zaten varsa temizle (Güncelleme mantığı)
        if (fs.existsSync(targetDir)) {
            try {
                fs.rmSync(targetDir, { recursive: true, force: true });
            } catch (e) {
                console.warn("Eski klasör silinemedi:", e);
            }
        }

        // Klasörü oluştur
        fs.mkdirSync(targetDir, { recursive: true });

        let command;
        if (os.platform() === 'win32') {
            // Windows için PowerShell ile ZIP çıkarma
            command = `powershell -command "Expand-Archive -Force -Path '${zxpFilePath}' -DestinationPath '${targetDir}'"`;
        } else {
            // Mac için yerleşik unzip komutu
            command = `unzip -o "${zxpFilePath}" -d "${targetDir}"`;
        }

        child_process.exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`ZXP Çıkarma Hatası: ${error.message}`);
                return reject(error);
            }
            console.log(`ZXP Başarıyla Kuruldu (Klasör: ${targetDir})`);
            resolve(targetDir);
        });
    });
}

module.exports = {
    installZXP
};
